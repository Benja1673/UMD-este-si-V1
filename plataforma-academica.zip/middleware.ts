import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Check if user is authenticated
  const isLoggedIn = request.cookies.get("isLoggedIn")?.value === "true"

  // If trying to access login or forgot-password and already authenticated, redirect to dashboard
  if (isLoggedIn && (request.nextUrl.pathname === "/login" || request.nextUrl.pathname === "/forgot-password")) {
    return NextResponse.redirect(new URL("/", request.url))
  }

  // If trying to access protected routes without authentication, redirect to login
  if (
    !isLoggedIn &&
    !request.nextUrl.pathname.startsWith("/login") &&
    !request.nextUrl.pathname.startsWith("/forgot-password") &&
    !request.nextUrl.pathname.startsWith("/_next") &&
    !request.nextUrl.pathname.startsWith("/api")
  ) {
    return NextResponse.redirect(new URL("/login", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
}
