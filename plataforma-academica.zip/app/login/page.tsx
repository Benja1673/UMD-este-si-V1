"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"

const LoginPage = () => {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    // Validación simple para el login de prueba
    if (username === "admin" && password === "1234") {
      // Guardar el estado de autenticación
      sessionStorage.setItem("isLoggedIn", "true")
      sessionStorage.setItem("username", username)

      // En una implementación real, aquí estableceríamos cookies o tokens JWT
      document.cookie = "isLoggedIn=true; path=/; max-age=3600"

      // Redirigir a la página principal
      router.push("/")
    } else {
      setError("Usuario o contraseña incorrectos")
    }
  }

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100">
      <div className="bg-white shadow-md rounded-lg p-8 w-full max-w-md">
        <div className="flex justify-center mb-8">
          <div className="flex items-center">
            <div className="mr-2">
              <img src="/placeholder.svg?height=60&width=60" alt="Logo UTEM" className="h-14" />
            </div>
            <div>
              <div className="text-3xl font-bold">
                <span className="text-blue-600">m</span>
                <span className="text-red-500">i</span>
                <span className="text-yellow-500">u</span>
                <span className="text-blue-800">t</span>
                <span className="text-green-500">e</span>
                <span className="text-black">m</span>
              </div>
              <div className="text-sm uppercase tracking-wider text-gray-700">TERRITORIO VIRTUAL</div>
            </div>
          </div>
        </div>

        <div className="text-center mb-6">
          <p className="text-gray-600">
            Por favor ingresa con tus credenciales de
            <br />
            Pasaporte.UTEM.
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-gray-500 text-sm uppercase mb-2" htmlFor="username">
              Usuario o Email
            </label>
            <input
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-purple-500"
              id="username"
              type="text"
              placeholder="usuario@utem.cl"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>

          <div className="mb-6">
            <label className="block text-gray-500 text-sm uppercase mb-2" htmlFor="password">
              Contraseña
            </label>
            <input
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-purple-500"
              id="password"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-medium py-3 px-4 rounded-md transition duration-300"
          >
            Ingresar
          </button>

          {error && <p className="text-red-500 text-sm mt-4 text-center">{error}</p>}
        </form>

        <div className="text-center mt-6">
          <Link href="/forgot-password" className="text-gray-500 hover:text-gray-700 text-sm">
            ¿Olvidó su contraseña?
          </Link>
        </div>
      </div>
    </div>
  )
}

export default LoginPage
