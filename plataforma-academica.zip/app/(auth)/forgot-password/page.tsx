import Link from "next/link"

export default function ForgotPasswordPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <div className="flex justify-center mb-8">
          <div className="flex items-center">
            <div className="mr-2">
              <img src="/placeholder.svg?height=60&width=60" alt="Logo UTEM" className="h-14" />
            </div>
            <div>
              <div className="text-3xl font-bold">
                <span className="text-blue-600">m</span>
                <span className="text-red-500">i</span>
                <span className="text-yellow-500">u</span>
                <span className="text-blue-800">t</span>
                <span className="text-green-500">e</span>
                <span className="text-black">m</span>
              </div>
              <div className="text-sm uppercase tracking-wider text-gray-700">TERRITORIO VIRTUAL</div>
            </div>
          </div>
        </div>

        <div className="text-center mb-6">
          <h2 className="text-xl font-semibold text-gray-800">Recuperar contraseña</h2>
          <p className="text-gray-600 mt-2">
            Ingresa tu correo electrónico y te enviaremos instrucciones para restablecer tu contraseña.
          </p>
        </div>

        <form>
          <div className="mb-6">
            <label htmlFor="email" className="block text-gray-500 text-sm uppercase mb-2">
              Correo electrónico
            </label>
            <input
              type="email"
              id="email"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-purple-500"
              placeholder="usuario@utem.cl"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-medium py-3 px-4 rounded-md transition duration-300"
          >
            Enviar instrucciones
          </button>
        </form>

        <div className="text-center mt-6">
          <Link href="/login" className="text-gray-500 hover:text-gray-700 text-sm">
            Volver al inicio de sesión
          </Link>
        </div>
      </div>
    </div>
  )
}
