import { PrismaClient, NivelCurso, EstadoCurso, EstadoDocente, Role, TipoCertificado } from "@prisma/client"
import bcrypt from "bcryptjs"

const prisma = new PrismaClient()

async function main() {
  console.log("🌱 Iniciando seed de la base de datos...")

  // Limpiar datos existentes en orden correcto
  await prisma.certificado.deleteMany()
  await prisma.inscripcionCurso.deleteMany()
  await prisma.cursoPrerequisito.deleteMany()
  await prisma.curso.deleteMany()
  await prisma.categoria.deleteMany()
  await prisma.docente.deleteMany()
  await prisma.departamento.deleteMany()
  await prisma.user.deleteMany()
  await prisma.evaluacion.deleteMany()
  await prisma.capacitacion.deleteMany()

  // Crear departamentos
  const departamentos = await Promise.all([
    prisma.departamento.create({
      data: {
        nombre: "Informática",
        codigo: "INF",
      },
    }),
    prisma.departamento.create({
      data: {
        nombre: "Matemáticas",
        codigo: "MAT",
      },
    }),
    prisma.departamento.create({
      data: {
        nombre: "Física",
        codigo: "FIS",
      },
    }),
    prisma.departamento.create({
      data: {
        nombre: "Educación",
        codigo: "EDU",
      },
    }),
    prisma.departamento.create({
      data: {
        nombre: "Humanidades",
        codigo: "HUM",
      },
    }),
    prisma.departamento.create({
      data: {
        nombre: "Investigación",
        codigo: "INV",
      },
    }),
    prisma.departamento.create({
      data: {
        nombre: "Ciencias Sociales",
        codigo: "CS",
      },
    }),
    prisma.departamento.create({
      data: {
        nombre: "Ingeniería",
        codigo: "ING",
      },
    }),
    prisma.departamento.create({
      data: {
        nombre: "Relaciones Internacionales",
        codigo: "RI",
      },
    }),
  ])

  // Crear categorías exactas según especificación
  const categorias = await Promise.all([
    // Nivel Inicial
    prisma.categoria.create({
      data: {
        nombre: "Modelo Educativo",
        descripcion: "Fundamentos del modelo educativo institucional",
        nivel: NivelCurso.INICIAL,
        orden: 1,
        esObligatoria: true,
      },
    }),

    // Nivel Intermedio
    prisma.categoria.create({
      data: {
        nombre: "Ambientes Propicios para el Aprendizaje",
        descripcion: "Creación de ambientes inclusivos y diversos para el aprendizaje",
        nivel: NivelCurso.INTERMEDIO,
        orden: 1,
        esObligatoria: true,
      },
    }),
    prisma.categoria.create({
      data: {
        nombre: "Enseñanza en Aula Centrada en el Estudiantado",
        descripcion: "Metodologías activas y evaluación centrada en el estudiante",
        nivel: NivelCurso.INTERMEDIO,
        orden: 2,
        esObligatoria: true,
      },
    }),
    prisma.categoria.create({
      data: {
        nombre: "Planificación de la Enseñanza",
        descripcion: "Diseño y planificación curricular efectiva",
        nivel: NivelCurso.INTERMEDIO,
        orden: 3,
        esObligatoria: true,
      },
    }),
    prisma.categoria.create({
      data: {
        nombre: "Reflexión sobre la Práctica Docente",
        descripcion: "Desarrollo profesional y reflexión pedagógica continua",
        nivel: NivelCurso.INTERMEDIO,
        orden: 4,
        esObligatoria: true,
      },
    }),

    // Nivel Avanzado
    prisma.categoria.create({
      data: {
        nombre: "Metodologías Vinculadas con el Entorno",
        descripcion: "Conexión con la comunidad y metodologías innovadoras",
        nivel: NivelCurso.AVANZADO,
        orden: 1,
        esObligatoria: true,
      },
    }),
    prisma.categoria.create({
      data: {
        nombre: "Didáctica",
        descripcion: "Didáctica especializada por disciplina",
        nivel: NivelCurso.AVANZADO,
        orden: 2,
        esObligatoria: true,
      },
    }),
  ])

  // Crear cursos exactos según especificación
  const cursos = await Promise.all([
    // Nivel Inicial - Modelo Educativo
    prisma.curso.create({
      data: {
        nombre: "Curso Modelo Educativo",
        codigo: "ME-001",
        nivel: NivelCurso.INICIAL,
        duracion: 40,
        modalidad: "Presencial",
        descripcion: "Curso fundamental sobre el modelo educativo institucional",
        categoriaId: categorias[0].id, // Modelo Educativo
        departamentoId: departamentos[3].id, // Educación
        cupos: 30,
      },
    }),

    // Nivel Intermedio - Ambientes Propicios para el Aprendizaje
    prisma.curso.create({
      data: {
        nombre: "Perspectiva de Género",
        codigo: "AP-001",
        nivel: NivelCurso.INTERMEDIO,
        duracion: 30,
        modalidad: "Virtual",
        descripcion: "Incorporación de la perspectiva de género en la educación",
        categoriaId: categorias[1].id, // Ambientes Propicios
        departamentoId: departamentos[3].id, // Educación
        cupos: 25,
      },
    }),
    prisma.curso.create({
      data: {
        nombre: "Neurodiversidad e Inclusión",
        codigo: "AP-002",
        nivel: NivelCurso.INTERMEDIO,
        duracion: 35,
        modalidad: "Híbrida",
        descripcion: "Estrategias para la inclusión de estudiantes neurodiversos",
        categoriaId: categorias[1].id, // Ambientes Propicios
        departamentoId: departamentos[3].id, // Educación
        cupos: 20,
      },
    }),

    // Nivel Intermedio - Enseñanza en Aula Centrada en el Estudiantado
    prisma.curso.create({
      data: {
        nombre: "Metodologías Activas",
        codigo: "EA-001",
        nivel: NivelCurso.INTERMEDIO,
        duracion: 45,
        modalidad: "Presencial",
        descripcion: "Implementación de metodologías activas de aprendizaje",
        categoriaId: categorias[2].id, // Enseñanza en Aula
        departamentoId: departamentos[3].id, // Educación
        cupos: 25,
      },
    }),
    prisma.curso.create({
      data: {
        nombre: "Evaluación",
        codigo: "EA-002",
        nivel: NivelCurso.INTERMEDIO,
        duracion: 40,
        modalidad: "Virtual",
        descripcion: "Estrategias de evaluación formativa y sumativa",
        categoriaId: categorias[2].id, // Enseñanza en Aula
        departamentoId: departamentos[3].id, // Educación
        cupos: 30,
      },
    }),

    // Nivel Intermedio - Planificación de la Enseñanza
    prisma.curso.create({
      data: {
        nombre: "Planificación de la Enseñanza",
        codigo: "PE-001",
        nivel: NivelCurso.INTERMEDIO,
        duracion: 50,
        modalidad: "Presencial",
        descripcion: "Diseño curricular y planificación de la enseñanza",
        categoriaId: categorias[3].id, // Planificación
        departamentoId: departamentos[3].id, // Educación
        cupos: 20,
      },
    }),

    // Nivel Intermedio - Reflexión sobre la Práctica Docente
    prisma.curso.create({
      data: {
        nombre: "DEDU",
        codigo: "RF-001",
        nivel: NivelCurso.INTERMEDIO,
        duracion: 60,
        modalidad: "Presencial",
        descripcion: "Desarrollo Educativo Docente Universitario",
        categoriaId: categorias[4].id, // Reflexión
        departamentoId: departamentos[3].id, // Educación
        cupos: 15,
      },
    }),
    prisma.curso.create({
      data: {
        nombre: "DIDU",
        codigo: "RF-002",
        nivel: NivelCurso.INTERMEDIO,
        duracion: 55,
        modalidad: "Virtual",
        descripcion: "Diplomado en Docencia Universitaria",
        categoriaId: categorias[4].id, // Reflexión
        departamentoId: departamentos[3].id, // Educación
        cupos: 20,
      },
    }),
    prisma.curso.create({
      data: {
        nombre: "Concursos Investigación y/o Innovación",
        codigo: "RF-003",
        nivel: NivelCurso.INTERMEDIO,
        duracion: 40,
        modalidad: "Virtual",
        descripcion: "Participación en concursos de investigación e innovación educativa",
        categoriaId: categorias[4].id, // Reflexión
        departamentoId: departamentos[5].id, // Investigación
        cupos: 25,
      },
    }),

    // Nivel Avanzado - Metodologías Vinculadas con el Entorno
    prisma.curso.create({
      data: {
        nombre: "A+S",
        codigo: "MV-001",
        nivel: NivelCurso.AVANZADO,
        duracion: 70,
        modalidad: "Presencial",
        descripcion: "Aprendizaje + Servicio: metodología de compromiso social",
        categoriaId: categorias[5].id, // Metodologías Vinculadas
        departamentoId: departamentos[6].id, // Ciencias Sociales
        cupos: 15,
      },
    }),
    prisma.curso.create({
      data: {
        nombre: "STEM",
        codigo: "MV-002",
        nivel: NivelCurso.AVANZADO,
        duracion: 65,
        modalidad: "Híbrida",
        descripcion: "Science, Technology, Engineering and Mathematics",
        categoriaId: categorias[5].id, // Metodologías Vinculadas
        departamentoId: departamentos[7].id, // Ingeniería
        cupos: 20,
      },
    }),
    prisma.curso.create({
      data: {
        nombre: "COIL",
        codigo: "MV-003",
        nivel: NivelCurso.AVANZADO,
        duracion: 60,
        modalidad: "Virtual",
        descripcion: "Collaborative Online International Learning",
        categoriaId: categorias[5].id, // Metodologías Vinculadas
        departamentoId: departamentos[8].id, // Relaciones Internacionales
        cupos: 25,
      },
    }),

    // Nivel Avanzado - Didáctica
    prisma.curso.create({
      data: {
        nombre: "Didáctica",
        codigo: "DID-001",
        nivel: NivelCurso.AVANZADO,
        duracion: 80,
        modalidad: "Presencial",
        descripcion: "Didáctica especializada por disciplina",
        categoriaId: categorias[6].id, // Didáctica
        departamentoId: departamentos[3].id, // Educación
        cupos: 18,
      },
    }),
  ])

  // Crear usuarios y docentes con diferentes niveles de progreso
  const hashedPassword = await bcrypt.hash("123456", 10)

  const usuarios = await Promise.all([
    // Usuario administrador
    prisma.user.create({
      data: {
        email: "admin@utem.cl",
        password: hashedPassword,
        role: Role.ADMIN,
      },
    }),

    // Usuarios docentes
    prisma.user.create({
      data: {
        email: "juan.perez@utem.cl",
        password: hashedPassword,
        role: Role.DOCENTE,
      },
    }),
    prisma.user.create({
      data: {
        email: "maria.gonzalez@utem.cl",
        password: hashedPassword,
        role: Role.DOCENTE,
      },
    }),
    prisma.user.create({
      data: {
        email: "carlos.rodriguez@utem.cl",
        password: hashedPassword,
        role: Role.DOCENTE,
      },
    }),
    prisma.user.create({
      data: {
        email: "ana.martinez@utem.cl",
        password: hashedPassword,
        role: Role.DOCENTE,
      },
    }),
    prisma.user.create({
      data: {
        email: "pedro.sanchez@utem.cl",
        password: hashedPassword,
        role: Role.DOCENTE,
      },
    }),
    prisma.user.create({
      data: {
        email: "lucia.torres@utem.cl",
        password: hashedPassword,
        role: Role.DOCENTE,
      },
    }),
    prisma.user.create({
      data: {
        email: "miguel.herrera@utem.cl",
        password: hashedPassword,
        role: Role.DOCENTE,
      },
    }),
  ])

  // Crear docentes con diferentes niveles
  const docentes = await Promise.all([
    // Juan Pérez - Nivel Intermedio (le falta una categoría)
    prisma.docente.create({
      data: {
        nombre: "Juan",
        apellido: "Pérez",
        rut: "12.345.678-9",
        email: "juan.perez@utem.cl",
        telefono: "+56 9 1234 5678",
        especialidad: "Programación",
        estado: EstadoDocente.ACTIVO,
        nivelActual: NivelCurso.INICIAL, // Será actualizado después
        userId: usuarios[1].id,
        departamentoId: departamentos[0].id, // Informática
      },
    }),
    // María González - Nivel Avanzado (completo)
    prisma.docente.create({
      data: {
        nombre: "María",
        apellido: "González",
        rut: "11.222.333-4",
        email: "maria.gonzalez@utem.cl",
        telefono: "+56 9 2345 6789",
        especialidad: "Álgebra",
        estado: EstadoDocente.ACTIVO,
        nivelActual: NivelCurso.AVANZADO,
        userId: usuarios[2].id,
        departamentoId: departamentos[1].id, // Matemáticas
      },
    }),
    // Carlos Rodríguez - Sin nivel (no ha aprobado Modelo Educativo)
    prisma.docente.create({
      data: {
        nombre: "Carlos",
        apellido: "Rodríguez",
        rut: "10.111.222-3",
        email: "carlos.rodriguez@utem.cl",
        telefono: "+56 9 3456 7890",
        especialidad: "Mecánica",
        estado: EstadoDocente.INACTIVO,
        nivelActual: null,
        userId: usuarios[3].id,
        departamentoId: departamentos[2].id, // Física
      },
    }),
    // Ana Martínez - Nivel Inicial (solo Modelo Educativo)
    prisma.docente.create({
      data: {
        nombre: "Ana",
        apellido: "Martínez",
        rut: "9.888.777-6",
        email: "ana.martinez@utem.cl",
        telefono: "+56 9 4567 8901",
        especialidad: "Bases de Datos",
        estado: EstadoDocente.ACTIVO,
        nivelActual: NivelCurso.INICIAL,
        userId: usuarios[4].id,
        departamentoId: departamentos[0].id, // Informática
      },
    }),
    // Pedro Sánchez - Nivel Intermedio (completo)
    prisma.docente.create({
      data: {
        nombre: "Pedro",
        apellido: "Sánchez",
        rut: "8.777.666-5",
        email: "pedro.sanchez@utem.cl",
        telefono: "+56 9 5678 9012",
        especialidad: "Estadística",
        estado: EstadoDocente.ACTIVO,
        nivelActual: NivelCurso.INTERMEDIO,
        userId: usuarios[5].id,
        departamentoId: departamentos[1].id, // Matemáticas
      },
    }),
    // Lucía Torres - Nivel Avanzado parcial (le falta Didáctica)
    prisma.docente.create({
      data: {
        nombre: "Lucía",
        apellido: "Torres",
        rut: "7.666.555-4",
        email: "lucia.torres@utem.cl",
        telefono: "+56 9 6789 0123",
        especialidad: "Literatura",
        estado: EstadoDocente.ACTIVO,
        nivelActual: NivelCurso.INTERMEDIO, // Será actualizado después
        userId: usuarios[6].id,
        departamentoId: departamentos[4].id, // Humanidades
      },
    }),
    // Miguel Herrera - En proceso nivel intermedio
    prisma.docente.create({
      data: {
        nombre: "Miguel",
        apellido: "Herrera",
        rut: "6.555.444-3",
        email: "miguel.herrera@utem.cl",
        telefono: "+56 9 7890 1234",
        especialidad: "Química",
        estado: EstadoDocente.ACTIVO,
        nivelActual: NivelCurso.INICIAL,
        userId: usuarios[7].id,
        departamentoId: departamentos[2].id, // Física
      },
    }),
  ])

  // Crear inscripciones detalladas para cada docente
  const inscripciones = [
    // Juan Pérez - Nivel Intermedio parcial (le falta Reflexión)
    { docenteId: docentes[0].id, cursoId: cursos[0].id, estado: EstadoCurso.APROBADO, nota: 85 }, // Modelo Educativo
    { docenteId: docentes[0].id, cursoId: cursos[1].id, estado: EstadoCurso.APROBADO, nota: 78 }, // Perspectiva de género
    { docenteId: docentes[0].id, cursoId: cursos[3].id, estado: EstadoCurso.APROBADO, nota: 82 }, // Metodologías Activas
    { docenteId: docentes[0].id, cursoId: cursos[5].id, estado: EstadoCurso.APROBADO, nota: 88 }, // Planificación
    { docenteId: docentes[0].id, cursoId: cursos[6].id, estado: EstadoCurso.EN_PROCESO }, // DEDU (en proceso)
    { docenteId: docentes[0].id, cursoId: cursos[2].id, estado: EstadoCurso.NO_INSCRITO }, // Neurodiversidad
    { docenteId: docentes[0].id, cursoId: cursos[4].id, estado: EstadoCurso.NO_INSCRITO }, // Evaluación

    // María González - Nivel Avanzado completo
    { docenteId: docentes[1].id, cursoId: cursos[0].id, estado: EstadoCurso.APROBADO, nota: 92 }, // Modelo Educativo
    { docenteId: docentes[1].id, cursoId: cursos[1].id, estado: EstadoCurso.APROBADO, nota: 89 }, // Perspectiva de género
    { docenteId: docentes[1].id, cursoId: cursos[3].id, estado: EstadoCurso.APROBADO, nota: 91 }, // Metodologías Activas
    { docenteId: docentes[1].id, cursoId: cursos[5].id, estado: EstadoCurso.APROBADO, nota: 87 }, // Planificación
    { docenteId: docentes[1].id, cursoId: cursos[7].id, estado: EstadoCurso.APROBADO, nota: 94 }, // DIDU
    { docenteId: docentes[1].id, cursoId: cursos[10].id, estado: EstadoCurso.APROBADO, nota: 86 }, // STEM
    { docenteId: docentes[1].id, cursoId: cursos[12].id, estado: EstadoCurso.APROBADO, nota: 90 }, // Didáctica

    // Carlos Rodríguez - Sin nivel (no ha aprobado nada)
    { docenteId: docentes[2].id, cursoId: cursos[0].id, estado: EstadoCurso.NO_APROBADO, nota: 45 }, // Modelo Educativo
    { docenteId: docentes[2].id, cursoId: cursos[1].id, estado: EstadoCurso.ABANDONADO }, // Perspectiva de género
    { docenteId: docentes[2].id, cursoId: cursos[3].id, estado: EstadoCurso.NO_INSCRITO }, // Metodologías Activas

    // Ana Martínez - Nivel Inicial solamente
    { docenteId: docentes[3].id, cursoId: cursos[0].id, estado: EstadoCurso.APROBADO, nota: 76 }, // Modelo Educativo
    { docenteId: docentes[3].id, cursoId: cursos[1].id, estado: EstadoCurso.INSCRITO }, // Perspectiva de género (inscrita)
    { docenteId: docentes[3].id, cursoId: cursos[3].id, estado: EstadoCurso.NO_INSCRITO }, // Metodologías Activas

    // Pedro Sánchez - Nivel Intermedio completo
    { docenteId: docentes[4].id, cursoId: cursos[0].id, estado: EstadoCurso.APROBADO, nota: 83 }, // Modelo Educativo
    { docenteId: docentes[4].id, cursoId: cursos[2].id, estado: EstadoCurso.APROBADO, nota: 79 }, // Neurodiversidad
    { docenteId: docentes[4].id, cursoId: cursos[4].id, estado: EstadoCurso.APROBADO, nota: 85 }, // Evaluación
    { docenteId: docentes[4].id, cursoId: cursos[5].id, estado: EstadoCurso.APROBADO, nota: 88 }, // Planificación
    { docenteId: docentes[4].id, cursoId: cursos[8].id, estado: EstadoCurso.APROBADO, nota: 81 }, // Concursos Investigación

    // Lucía Torres - Nivel Avanzado parcial (le falta Didáctica)
    { docenteId: docentes[5].id, cursoId: cursos[0].id, estado: EstadoCurso.APROBADO, nota: 87 }, // Modelo Educativo
    { docenteId: docentes[5].id, cursoId: cursos[1].id, estado: EstadoCurso.APROBADO, nota: 92 }, // Perspectiva de género
    { docenteId: docentes[5].id, cursoId: cursos[4].id, estado: EstadoCurso.APROBADO, nota: 89 }, // Evaluación
    { docenteId: docentes[5].id, cursoId: cursos[5].id, estado: EstadoCurso.APROBADO, nota: 91 }, // Planificación
    { docenteId: docentes[5].id, cursoId: cursos[6].id, estado: EstadoCurso.APROBADO, nota: 86 }, // DEDU
    { docenteId: docentes[5].id, cursoId: cursos[9].id, estado: EstadoCurso.APROBADO, nota: 84 }, // A+S
    { docenteId: docentes[5].id, cursoId: cursos[12].id, estado: EstadoCurso.INSCRITO }, // Didáctica (inscrita)

    // Miguel Herrera - En proceso nivel intermedio
    { docenteId: docentes[6].id, cursoId: cursos[0].id, estado: EstadoCurso.APROBADO, nota: 74 }, // Modelo Educativo
    { docenteId: docentes[6].id, cursoId: cursos[1].id, estado: EstadoCurso.EN_PROCESO }, // Perspectiva de género
    { docenteId: docentes[6].id, cursoId: cursos[3].id, estado: EstadoCurso.INSCRITO }, // Metodologías Activas
  ]

  await Promise.all(
    inscripciones.map((inscripcion) =>
      prisma.inscripcionCurso.create({
        data: {
          docenteId: inscripcion.docenteId,
          cursoId: inscripcion.cursoId,
          estado: inscripcion.estado,
          fechaInscripcion: inscripcion.estado !== EstadoCurso.NO_INSCRITO ? new Date() : null,
          fechaAprobacion: inscripcion.estado === EstadoCurso.APROBADO ? new Date() : null,
          nota: inscripcion.nota || null,
        },
      }),
    ),
  )

  // Crear prerrequisitos: Modelo Educativo es prerrequisito para todos los de nivel intermedio
  const prerrequisitosIntermedios = cursos.slice(1, 9).map((curso) => ({
    cursoId: curso.id,
    prerrequisitoCursoId: cursos[0].id, // Modelo Educativo
  }))

  // Los cursos de nivel avanzado requieren haber completado el nivel intermedio
  const prerrequisitosAvanzados = cursos.slice(9).map((curso) => ({
    cursoId: curso.id,
    prerrequisitoCursoId: cursos[0].id, // Modelo Educativo como base
  }))

  await Promise.all([
    ...prerrequisitosIntermedios.map((prereq) => prisma.cursoPrerequisito.create({ data: prereq })),
    ...prerrequisitosAvanzados.map((prereq) => prisma.cursoPrerequisito.create({ data: prereq })),
  ])

  // Crear algunos certificados de ejemplo
  await Promise.all([
    prisma.certificado.create({
      data: {
        titulo: "Certificado Nivel Inicial",
        descripcion: "Certificado de completación del nivel inicial",
        tipo: TipoCertificado.NIVEL,
        fechaEmision: new Date(),
        codigoVerificacion: "CERT-INICIAL-001",
        docenteId: docentes[3].id, // Ana Martínez
      },
    }),
    prisma.certificado.create({
      data: {
        titulo: "Certificado Nivel Intermedio",
        descripcion: "Certificado de completación del nivel intermedio",
        tipo: TipoCertificado.NIVEL,
        fechaEmision: new Date(),
        codigoVerificacion: "CERT-INTER-001",
        docenteId: docentes[4].id, // Pedro Sánchez
      },
    }),
    prisma.certificado.create({
      data: {
        titulo: "Certificado Nivel Avanzado",
        descripción: "Certificado de completación del nivel avanzado",
        tipo: TipoCertificado.NIVEL,
        fechaEmision: new Date(),
        codigoVerificacion: "CERT-AVANZ-001",
        docenteId: docentes[1].id, // María González
      },
    }),
  ])

  console.log("✅ Seed completado exitosamente!")
  console.log(`📊 Datos creados:`)
  console.log(`   - ${departamentos.length} departamentos`)
  console.log(`   - ${categorias.length} categorías`)
  console.log(`   - ${cursos.length} cursos`)
  console.log(`   - ${usuarios.length} usuarios`)
  console.log(`   - ${docentes.length} docentes`)
  console.log(`   - ${inscripciones.length} inscripciones`)
  console.log(`\n📚 Estructura de cursos por nivel:`)
  console.log(`   🟢 Inicial: 1 curso (Modelo Educativo)`)
  console.log(`   🔵 Intermedio: 8 cursos en 4 categorías`)
  console.log(`   🟡 Avanzado: 4 cursos en 2 categorías`)
  console.log(`\n👥 Docentes por nivel:`)
  console.log(`   - Sin nivel: Carlos Rodríguez`)
  console.log(`   - Inicial: Ana Martínez, Miguel Herrera`)
  console.log(`   - Intermedio: Juan Pérez (parcial), Pedro Sánchez, Lucía Torres (parcial)`)
  console.log(`   - Avanzado: María González`)
  console.log(`\n🔑 Credenciales de acceso:`)
  console.log(`   Admin: admin@utem.cl / 123456`)
  console.log(`   Docentes: [nombre.apellido]@utem.cl / 123456`)
}

main()
  .catch((e) => {
    console.error("❌ Error durante el seed:", e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
